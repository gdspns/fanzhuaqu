# FanVPN 节点分发中心

一个自动化 VPN 节点抓取、解密与订阅分发系统，带可视化管理面板。

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — 运行 API 服务器 (port 8080)
- `pnpm run typecheck` — 全量类型检查
- `pnpm run build` — 构建所有包
- 管理面板访问地址: `/api/dashboard`（默认密码: `admin`）

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- 解密: Node.js `crypto` 模块（RSA-OAEP + AES-256-CBC）
- 订阅定时更新: 每 2 小时拉取一次
- Build: esbuild (ESM bundle)

## Where things live

- `artifacts/api-server/src/lib/fanvpn.ts` — 核心解密逻辑、节点数据、定时拉取
- `artifacts/api-server/src/routes/fanvpn.ts` — 路由：管理面板、状态 API、订阅接口
- `artifacts/api-server/src/app.ts` — Express 应用入口，启动节点调度器

## Architecture decisions

- 所有 FanVPN 路由挂载在 `/api` 前缀下，与现有代理配置兼容
- 节点数据存储在内存中（`nodeData` 对象），每 2 小时从远端拉取刷新
- 使用 RSA-OAEP + AES-256-CBC 双层加密，私钥内置在服务端
- 订阅管理数据保存在前端 `localStorage`，无需后端存储
- 面板登录密码纯前端校验（`admin`），适合轻量使用场景

## Product

- 管理面板：`/api/dashboard` — 登录后查看所有节点，管理订阅链接
- Clash 订阅：`/api/sub/clash` 或 `/api/sub/clash/:token`
- Base64 订阅：`/api/sub/base64` 或 `/api/sub/base64/:token`
- 状态接口：`/api/status` — 返回节点数量、最后更新时间

## User preferences

- 代码原封不动部署，保留原始逻辑和结构

## Gotchas

- 节点拉取依赖外部 URL，启动后约几秒完成首次拉取
- 默认管理员密码是 `admin`，可在 `routes/fanvpn.ts` 中修改 `DASHBOARD_HTML` 里的登录逻辑
- 私钥硬编码在 `lib/fanvpn.ts` 中，与原始代码保持一致

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
