import { Router, type IRouter } from "express";
import healthRouter from "./health.js";
import fanvpnRouter from "./fanvpn.js";

const router: IRouter = Router();

router.use(healthRouter);
router.use(fanvpnRouter);

export default router;
